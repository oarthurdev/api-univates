INSERT INTO public.phinxlog (version,migration_name,start_time,end_time,breakpoint) VALUES (20220810135351,'Persons','2022-08-10 14:01:40','2022-08-10 14:01:40','');
