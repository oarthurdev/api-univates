INSERT INTO public.person (id,name,birth_date,cpf,sex,phone,email,created,updated) VALUES (2,'Arthur','12/10/1995',09932952907,'Male',4733339139,'oarthurdev@gmail.com','2022-08-10 00:00:00','');
